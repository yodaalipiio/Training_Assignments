var eamount,disco,tamount;

function dispval() {
    
    var electitem = document.getElementById("Eitem");  
    eamount = document.getElementById("price").value = electitem.options[electitem.selectedIndex].value; 
        
  }
  function check(disc) {
   disco =disc*eamount;
   document.getElementById("tprice").value=disco;
  }
  function myFunction() {
    var x = document.getElementById("inprice").value;
    tamount=disco*x;
    alert("Order Placement is Successful! Amount to be paid is:  "+tamount);

    ///document.getElementById("demo").innerHTML = x;
  }