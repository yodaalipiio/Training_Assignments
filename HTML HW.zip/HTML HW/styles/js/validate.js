function checkPassword(){
    let pwd1 = document.getElementById("pwd1").value;
    let pwd2 = document.getElementById("pwd2").value;
    console.log(pwd1, pwd2);

    let message = document.getElementById("message");

    if (pwd1.length != 0){
        if(pwd1 == pwd2){
            message.textContent = "Passwords match";
            message.style.backgroundColor = "#4caf50";
        }
        else {
            message.textContent = "Passwords do not match";
            message.style.backgroundColor = "#f44335";
        }
    }

    else {
        alert("Password cannot be empty");
        message.textContent ="";
    }

}