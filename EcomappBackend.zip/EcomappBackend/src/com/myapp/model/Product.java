package com.myapp.model;

public class Product{
	
	private static int productId;
	private static String prodName;
	private static float prodPrice;
	
	public Product() {
		
	}
	
	public Product(int productId, String prodName, float prodPrice) {
		super();
		this.productId = productId;
		this.prodName = prodName;
		this.prodPrice = prodPrice;
	}
	
	public static int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public static String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public static float getProdPrice() {
		return prodPrice;
	}
	public void setProdPrice(float prodPrice) {
		this.prodPrice = prodPrice;
	}
	
	
	
	

}
