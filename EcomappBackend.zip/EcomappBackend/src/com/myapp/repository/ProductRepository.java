package com.myapp.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.myapp.dao.ProductDAO;
import com.myapp.model.Product;
import com.myapp.utility.DbConnect;

public class ProductRepository implements ProductDAO{
	DbConnect db;
    Connection con;
    
    public ProductRepository() {
    	db = new DbConnect();
        con = db.getConnection();
    }
    
	@Override
	public boolean addProduct(Product product) {
		Connection con=null;
		try {
		  con = DbConnect.getConnection();
			System.out.println("add called from Product repo");
			//db = new DbConnect();
			//con = db.getConnection();
			PreparedStatement stmt = con.prepareStatement(
					"INSERT INTO products (productId, prodName, prodPrice)"
							+ " values (?, ?, ?)");
			stmt.setInt(1, Product.getProductId());
			stmt.setString(2, Product.getProdName());
			stmt.setFloat(3, Product.getProdPrice());
			stmt.executeUpdate();
			con.close();
			System.out.println("record added");
			return true;
		} catch (SQLException e) {
			System.out.println(e);
		}finally {
			
		}
		return false;
	}

	@Override
	public boolean deleteProduct(int prodId) {
//		try {
//			Connection con = db.getConnection();
//			PreparedStatement stmt = con.prepareStatement("DELETE FROM products WHERE prodid=?");
//			stmt.setInt(1, prodId);
//			stmt.executeUpdate();
//			con.close();
//			return true;
//		} catch (SQLException e) {
//			System.out.println(e);
//		}
		return false;

	}
	

}
