create table userinfo
(
employeeid number(6) primary key,
employeename varchar2(30) not null,
email varchar2(30) unique not null,
emppassword varchar2(30) ,
role_type varchar2(30),
deptname varchar2(30)
)

insert into userinfo values(1236, 'john', 'john@gmail.com', 'hahahaha', 'lala', 'lab' );
insert into userinfo values(2468, 'michael', 'michael@email.com','hehehehe', 'lele', 'xyz');
================================
create table skills
(
skillid number(6),
employeeid number(6) unique,
skilltype varchar2(30),
skilldesc varchar2(100) ,
certifications varchar2(100),
teachinghrs number(5),
studentstrained number(5),
feedbackrating number(2),
constraint empfk foreign key(employeeid)  references userinfo(employeeid)
)

insert into skills values(2468,1236, 'cooking', 'cooking_food','cert',400,20,10);
======================================

create table userprofile
(
profileid number(6),
employeeid number(5) references userinfo(employeeid),
city varchar2(30),
region varchar2(20),
qualification varchar2(30),
supervisorname varchar2(30),
profileviews number(2),
profileselected number(2),
profilephoto VARCHAR2(30)
)

insert into userprofile values(0001, 1236, 'Manila','NCR', 'instructor', 'jane', 30, 1, 'photo.jpg');
===============================

create table products
(
productid number(10) primary key,
prodname varchar2(30),
prodprice float(10)
);

drop table products;

insert into products values(123, 'gpu', 15000);
insert into products values(246, 'pixel', 22000);

select * from products;